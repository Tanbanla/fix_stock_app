//
//  SideMenuModel.swift
//  BIVN
//
//  Created by Tinhvan on 12/09/2023.
//

import Foundation
import UIKit

struct SideMenuModel {
    var icon: UIImage
    var title: String
}
