//
//  StatusModel.swift
//  BIVN
//
//  Created by Bi on 5/2/25.
//

import Foundation
import Localize_Swift

class StatusModel: Codable {
    var message: String?
    var code: Int?
}

