//
//  AccessoryModel.swift
//  BIVN
//
//  Created by Tinhvan on 22/11/2023.
//

import Foundation

struct AccessoryModel {
    var content: String
    var code: String
    var boxes: String
    
}
