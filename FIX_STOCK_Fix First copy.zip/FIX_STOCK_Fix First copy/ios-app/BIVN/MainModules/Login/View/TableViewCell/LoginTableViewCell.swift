//
//  LoginTableViewCell.swift
//  BIVN
//
//  Created by Luyện Đào on 14/09/2023.
//

import UIKit

class LoginTableViewCell: UITableViewCell {
    @IBOutlet weak var nameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
