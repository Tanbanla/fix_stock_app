//
//  DocOutPutRequestModel.swift
//  BIVN
//
//  Created by Luyện Đào on 30/11/2023.
//

import Foundation

class DocOutPutRequestModel {
    var id: String?
    var quantityOfBom: Int?
    var quantityPerBom: Int?
}
