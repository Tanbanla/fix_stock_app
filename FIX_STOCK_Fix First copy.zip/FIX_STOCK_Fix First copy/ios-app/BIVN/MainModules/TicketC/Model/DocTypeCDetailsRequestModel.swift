//
//  DocTypeCDetailsRequestModel.swift
//  BIVN
//
//  Created by Luyện Đào on 30/11/2023.
//

import Foundation

struct DocTypeCDetailsRequestModel {
    var id: String
    var componentCode: String
    var quantityOfBom: String
    var quantityPerBom: String
}
