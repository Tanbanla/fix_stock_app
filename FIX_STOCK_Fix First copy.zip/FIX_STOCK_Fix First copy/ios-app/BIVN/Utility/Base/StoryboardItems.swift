//
//  StoryboardItems.swift
//  BIVN
//
//  Created by Tan Tran on 22/11/2023.
//

import Foundation

// MARK: - Storyboards
enum Storyboards {
    case login
    case inventoryUser
    case main
    case detailHistory
    case qrInventory
}

