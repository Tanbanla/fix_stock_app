//
//  Notifications.swift
//  BIVN
//
//  Created by Luyện Đào on 28/12/2023.
//

import Foundation

extension Notification.Name {
    static let reloadStatus = Notification.Name("reloadStatus")
}
